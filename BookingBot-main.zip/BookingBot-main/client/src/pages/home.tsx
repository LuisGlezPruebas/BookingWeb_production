import UserSelection from "@/components/user-selection";

export default function HomePage() {
  return <UserSelection />;
}
